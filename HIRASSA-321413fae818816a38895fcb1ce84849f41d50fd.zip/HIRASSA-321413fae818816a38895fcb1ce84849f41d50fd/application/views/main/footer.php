</div>
<script src="<?php echo base_url('/public/js/jquery-1.10.2.js'); ?>"></script>
<script src="<?php echo base_url('/public/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('/public/js/jquery.metisMenu.js'); ?>"></script>
<script src="<?php echo base_url('/public/js/custom.js'); ?>"></script>
    <!--import jquery confirme-->
    <script src="<?php echo base_url('/public/js/jquery.js'); ?>"></script>
    <link href="<?php echo base_url('/public/css/jquery-confirm.css'); ?>" rel="stylesheet" />
    <script src="<?php echo base_url('/public/js/jquery.confirm.js'); ?>"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
    <script src="<?php echo base_url('/public/js/prof/prof.js'); ?>"></script>
</body>
</html>