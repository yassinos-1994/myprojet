<?php

class Users_model extends CI_Model
{
    
}
