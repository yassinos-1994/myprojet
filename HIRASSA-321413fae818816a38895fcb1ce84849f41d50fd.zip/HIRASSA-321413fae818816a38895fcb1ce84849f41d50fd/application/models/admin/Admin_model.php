<?php

class Admin_model extends CI_Model
{
    
}
